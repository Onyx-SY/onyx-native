#!/usr/bin/env python3
"""离线验证子代理执行层白名单闸：explore/plan 只能运行只读白名单工具，
模型幻觉调用 Agent（嵌套套娃）/ RunCommand（非只读）一律拒绝。

运行: python3 test/virtual/test_subagent_whitelist.py
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", ".."))

from bin.ai_lib import api as api_mod  # noqa: E402
from bin import ai_cmd as ai_cmd_mod  # noqa: E402
from bin.ai_lib import subagent as sa  # noqa: E402

_orig_api = api_mod.call_ai_api_sse
_orig_exec = ai_cmd_mod.execute_mcp_tool
_orig_executor = None


def _fake_api_factory(round1_calls, round1_tools):
    """返回 fake call_ai_api_sse：第一轮返回 round1_tools，之后返回总结。"""
    state = {"n": 0, "seen_msgs": None}

    def fake_api(**kw):
        state["n"] += 1
        if state["n"] == 1:
            return {"tool_calls": round1_tools, "_reasoning": ""}
        state["seen_msgs"] = kw.get("messages") or []
        return {"txt": "## Explore Summary\n调查完成", "_reasoning": ""}

    return fake_api, state


def _run(task, fake_api):
    api_mod.call_ai_api_sse = fake_api
    mgr = sa.ExploreManager()
    try:
        mgr._run_task(task)  # 走完整入口（信号量 + finally 置 done）
    finally:
        api_mod.call_ai_api_sse = _orig_api
    return task


def test_explore_rejects_agent_and_runcommand():
    exec_calls = []
    ai_cmd_mod.execute_mcp_tool = lambda *a, **k: (exec_calls.append(a[0]), (True, "ok"))[1]
    fake_api, state = _fake_api_factory(1, [
        {"name": "Agent", "params_str": '{"prompt":"套娃测试"}'},
        {"name": "RunCommand", "params_str": '{"command":"rm -rf /"}'},
        {"name": "read_file", "params_str": '{"path":"/x"}'},
    ])
    task = _run(sa.ExploreTask("测试", agent_type="explore"), fake_api)
    assert task.status == "done" and task.summary
    # 只有 read_file 被真正执行；Agent/RunCommand 被白名单拒绝
    assert exec_calls == ["read_file"], f"应只执行 read_file, 实际 {exec_calls}"
    # 第二轮发给模型的 tool 结果里含拒绝消息
    tool_msgs = [m.get("content", "") for m in state["seen_msgs"] if m.get("role") == "tool"]
    joined = "\n".join(tool_msgs)
    assert "白名单" in joined and "Agent" in joined and "RunCommand" in joined
    assert "read_file" in joined
    print("PASS explore：Agent/RunCommand 被拒（防套娃+防非只读），read_file 正常执行")


def test_lint_allows_runcommand_via_pipeline():
    exec_calls = []
    ai_cmd_mod.execute_mcp_tool = lambda *a, **k: (exec_calls.append(a[0]), (True, "ok"))[1]
    fake_api, state = _fake_api_factory(1, [
        {"name": "RunCommand", "params_str": '{"command":"pytest"}'},
    ])
    task = _run(sa.ExploreTask("测试", agent_type="lint"), fake_api)
    assert task.status == "done"
    # lint 白名单含 RunCommand → 不走 execute_mcp_tool，走安全管线
    assert exec_calls == [], f"RunCommand 不应进 execute_mcp_tool, 实际 {exec_calls}"
    tool_msgs = [m.get("content", "") for m in state["seen_msgs"] if m.get("role") == "tool"]
    joined = "\n".join(tool_msgs)
    assert "白名单" not in joined, "lint 的 RunCommand 不应被白名单拒绝"
    print("PASS lint：RunCommand 经安全管线放行（不被白名单拒绝）")


if __name__ == "__main__":
    try:
        test_explore_rejects_agent_and_runcommand()
        test_lint_allows_runcommand_via_pipeline()
        print("\nALL PASS")
    finally:
        api_mod.call_ai_api_sse = _orig_api
        ai_cmd_mod.execute_mcp_tool = _orig_exec
